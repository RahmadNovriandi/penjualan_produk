<?php

namespace App\Http\Controllers;

//import Model "Post
use App\Models\Post;

//return type View
use Illuminate\View\View;

//return type redirectResponse
use Illuminate\Http\RedirectResponse;

use Illuminate\Http\Request;

class PostController extends Controller
{
    /**
     * index
     *
     * @return View
     */
    public function index(): View
    {
        //get posts
        $posts = Post::latest()->paginate(5);

        //render view with posts
        return view('posts.index', compact('posts'));
    }

    /**
     * create
     *
     * @return View
     */
    public function create(): View
    {
        return view('posts.create');
    }

    /**
     * store
     *
     * @param  mixed $request
     * @return RedirectResponse
     */
    public function store(Request $request): RedirectResponse
    {
        //validate form
        $this->validate($request, [
            'kode_buku'       => 'required|min:5',
            'judul_buku'      => 'required|min:40',
            'kategori_buku'   => 'required|min:20',
            'tahun_buku'      => 'required|min:5',
            'penerbit'        => 'required|min:100',
        ]);

       
        //create post
        Post::create([
            'kode_buku'      => $request->kode_buku,
            'judul_buku'     => $request->judul_buku,
            'kategori_buku'  => $request->kategori_buku,
            'tahun_buku'     => $request->tahun_buku,
            'penerbit'       => $request->penerbit,
        ]);

        //redirect to index
        return redirect()->route('posts.index')->with(['success' => 'Data Berhasil Disimpan!']);
    }
}
